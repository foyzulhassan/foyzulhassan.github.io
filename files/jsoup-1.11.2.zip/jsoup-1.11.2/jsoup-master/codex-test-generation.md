# Codex CLI — Automated Unit Test Generation

You are performing automated unit test generation for **jsoup version 1.11.2** as part of a Software Quality Assurance experiment.

**Target class:** Use the fully qualified Java class name supplied in the user's Codex CLI request.

Generate **JUnit 4** unit tests for that class.

## Requirements

1. Analyze the target production class and its relevant production-code dependencies.
2. Generate unit tests targeting high line and branch coverage.
3. Include normal, boundary, exceptional, and invalid-input scenarios where applicable.
4. Include meaningful assertions that verify expected behavior.
5. Do not inspect, copy, or reuse existing human-written or EvoSuite-generated tests.
6. Do not modify production source code, existing tests, or Maven configuration.
7. Do not invoke EvoSuite or any other automated test generation tool.

## Test file location and naming

8. Save all generated tests under `codex-tests` at the project root.
9. Preserve the Java package structure. For example, for `org.jsoup.nodes.Element`, save tests at `codex-tests/org/jsoup/nodes/ElementCodexTest.java`.
10. Name generated test classes using the convention `<OriginalClassName>CodexTest`.
11. Use JUnit 4 and ensure compatibility with jsoup 1.11.2 and Java 8.

## Execution constraints

12. Generate the initial test suite without executing it.
13. Do not debug, repair, or refine the generated tests.
14. Stop after generating and saving the test files. Do not provide a summary of the test scenarios.
