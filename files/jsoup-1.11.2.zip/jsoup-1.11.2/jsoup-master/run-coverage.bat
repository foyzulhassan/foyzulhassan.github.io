@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Run from the directory containing this script and pom.xml.
cd /d "%~dp0"

if /I "%~1"=="human" goto selected
if /I "%~1"=="evosuite" goto selected
if /I "%~1"=="codex" goto selected

echo Usage: run-coverage.bat human^|evosuite^|codex
exit /b 1

:selected
set "SUITE=%~1"
set "WORK=%CD%\.coverage-work"
set "WORK_DIR=%WORK%"
set "OUT=%CD%\coverage-reports\%SUITE%"
set "TESTPATTERN="
set "JACOCO_CLI=org.jacoco.cli-0.8.12-nodeps.jar"

if not exist "pom.xml" (
  echo ERROR: Place this file beside jsoup's pom.xml.
  exit /b 1
)

rem Only delete the fixed temporary workspace beside this script.
if /I not "%WORK%"=="%CD%\.coverage-work" (
  echo ERROR: Unexpected workspace path. Refusing to delete.
  exit /b 1
)
if exist "%WORK%" (
  echo Removing previous temporary workspace...
  rmdir /s /q "%WORK%"
  if exist "%WORK%" (
    echo ERROR: Could not remove %WORK%. Close programs using it.
    exit /b 1
  )
)

if /I "%SUITE%"=="evosuite" (
  if not exist "evosuite-tests\" (
    echo ERROR: evosuite-tests folder not found.
    exit /b 1
  )
  set "TESTPATTERN=*_ESTest"
)
if /I "%SUITE%"=="codex" (
  if not exist "codex-tests\" (
    echo ERROR: codex-tests folder not found.
    exit /b 1
  )
  set "TESTPATTERN=*CodexTest"
)

rem Copy the project; never modify the original POM or tests.
echo Preparing isolated %SUITE% workspace...
robocopy "%CD%" "%WORK%" /E /XD ".git" "target" ".coverage-work" "coverage-reports" /XF "*.log" >nul
if errorlevel 8 (
  echo ERROR: Failed to create temporary workspace.
  exit /b 1
)

if /I not "%SUITE%"=="human" (
  if exist "%WORK%\src\test\java" rmdir /s /q "%WORK%\src\test\java"
  mkdir "%WORK%\src\test\java"
  if /I "%SUITE%"=="evosuite" set "SOURCE=%WORK%\evosuite-tests"
  if /I "%SUITE%"=="codex" set "SOURCE=%WORK%\codex-tests"
  xcopy "!SOURCE!\*" "%WORK%\src\test\java\" /E /I /Y /Q >nul
  if errorlevel 1 (
    echo ERROR: Failed to copy selected tests.
    goto failed
  )
  if /I "%SUITE%"=="evosuite" (
    for /r "%WORK%\src\test\java" %%F in (*CodexTest.java) do del /q "%%F"
    for /r "%WORK%\src\test\java" %%F in (*CodexTest.class) do del /q "%%F"
  )
  if /I "%SUITE%"=="codex" (
    for /r "%WORK%\src\test\java" %%F in (*_ESTest.java *_ESTest_scaffolding.java) do del /q "%%F"
  )
)

rem Add EvoSuite runtime ONLY to the temporary pom.xml.
if /I "%SUITE%"=="evosuite" (
  echo Adding EvoSuite runtime to temporary Maven project...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; try { $p=Join-Path $env:WORK_DIR 'pom.xml'; [xml]$x=Get-Content -LiteralPath $p -Raw; $root=$x.DocumentElement; $ns=$root.NamespaceURI; $blocks=@($root.SelectNodes('./*[local-name()=''dependencies'']')); if($blocks.Count -gt 1){ throw 'Multiple top-level dependencies sections' }; if($blocks.Count -eq 1){ $deps=$blocks[0] } else { $deps=$x.CreateElement('dependencies',$ns); [void]$root.AppendChild($deps) }; $matches=@($deps.SelectNodes('./*[local-name()=''dependency'' and *[local-name()=''groupId'' and text()=''org.evosuite''] and *[local-name()=''artifactId'' and text()=''evosuite-standalone-runtime'']]')); foreach($old in $matches){ [void]$deps.RemoveChild($old) }; $dep=$x.CreateElement('dependency',$ns); foreach($pair in @(@('groupId','org.evosuite'),@('artifactId','evosuite-standalone-runtime'),@('version','1.0.6'),@('scope','test'))){ $el=$x.CreateElement($pair[0],$ns); $el.InnerText=$pair[1]; [void]$dep.AppendChild($el) }; [void]$deps.AppendChild($dep); $x.Save($p) } catch { Write-Error $_; exit 1 }"
  if errorlevel 1 (
    echo ERROR: Failed to add EvoSuite runtime to temporary pom.xml.
    goto failed
  )
)

pushd "%WORK%"
if /I "%SUITE%"=="evosuite" goto offline_evosuite

echo Running %SUITE% tests with JaCoCo Java agent...
if defined TESTPATTERN (
  call mvn clean org.jacoco:jacoco-maven-plugin:0.8.12:prepare-agent test "-Dtest=%TESTPATTERN%" "-DfailIfNoTests=true" "-Dmaven.test.failure.ignore=true"
) else (
  call mvn clean org.jacoco:jacoco-maven-plugin:0.8.12:prepare-agent test "-DfailIfNoTests=true" "-Dmaven.test.failure.ignore=true"
)
if not exist "target\jacoco.exec" goto missing_exec
goto tests_done

:offline_evosuite
rem Offline instrumentation avoids competing Java agents on jsoup production classes.
rem The uploaded POM already includes org.jacoco.agent:runtime as a test dependency.
echo Compiling EvoSuite tests and production classes...
call mvn clean test-compile "-DskipTests"
if errorlevel 1 goto maven_failed

rem Explicitly set offline agent output, independent of EvoSuite's user.dir changes.
if not exist "target\test-classes" mkdir "target\test-classes"
set "EXEC_DEST=%WORK%\target\jacoco.exec"
set "EXEC_DEST=!EXEC_DEST:\=/!"
> "target\test-classes\jacoco-agent.properties" echo output=file
>> "target\test-classes\jacoco-agent.properties" echo destfile=!EXEC_DEST!
>> "target\test-classes\jacoco-agent.properties" echo append=false

echo Instrumenting production classes offline...
call mvn org.jacoco:jacoco-maven-plugin:0.8.12:instrument
if errorlevel 1 goto maven_failed

echo Running EvoSuite tests against offline-instrumented production classes...
call mvn surefire:test "-Dtest=%TESTPATTERN%" "-DfailIfNoTests=true"
if errorlevel 1 goto maven_failed

rem Restore uninstrumented classes before generating the report; IDs must match.
echo Restoring original production classes for reporting...
call mvn org.jacoco:jacoco-maven-plugin:0.8.12:restore-instrumented-classes
if errorlevel 1 goto maven_failed
if not exist "target\jacoco.exec" goto missing_exec
goto tests_done

:maven_failed
popd
echo ERROR: Maven build or tests failed. Workspace retained: %WORK%
exit /b 1

:missing_exec
popd
echo ERROR: JaCoCo execution data not found in target\jacoco.exec.
echo Check EvoSuite classloading and offline runtime initialization.
echo Workspace retained: %WORK%
exit /b 1

:tests_done
rem Fetch the standalone JaCoCo CLI into the workspace.
echo Preparing JaCoCo CLI...
call mvn dependency:copy "-Dartifact=org.jacoco:org.jacoco.cli:0.8.12:jar:nodeps" "-DoutputDirectory=."
if errorlevel 1 (
  popd
  echo ERROR: Could not download JaCoCo CLI.
  exit /b 1
)
if not exist "%JACOCO_CLI%" (
  popd
  echo ERROR: JaCoCo CLI JAR not found: %WORK%\%JACOCO_CLI%
  exit /b 1
)

rem Generate the HTML and CSV from the same exec file and compiled classes.
rem Reporting against the original, uninstrumented compiled classes.
if exist "%OUT%" rmdir /s /q "%OUT%"
if exist "%OUT%" (
  popd
  echo ERROR: Could not remove old report: %OUT%
  exit /b 1
)
mkdir "%OUT%"
if errorlevel 1 (
  popd
  echo ERROR: Could not create report folder: %OUT%
  exit /b 1
)
echo Generating %SUITE% coverage using JaCoCo CLI...
java -jar "%JACOCO_CLI%" report "target\jacoco.exec" --classfiles "target\classes" --sourcefiles "src\main\java" --html "%OUT%" --csv "%OUT%\jacoco.csv"
if errorlevel 1 (
  popd
  echo ERROR: JaCoCo CLI report generation failed.
  exit /b 1
)
popd

if not exist "%OUT%\index.html" (
  echo ERROR: HTML report was not generated.
  exit /b 1
)
if not exist "%OUT%\jacoco.csv" (
  echo ERROR: CSV report was not generated.
  exit /b 1
)

rem Display total covered instructions as a simple verification.
powershell -NoProfile -Command "$r=Import-Csv -LiteralPath '%OUT%\jacoco.csv'; $n=($r | Measure-Object -Property INSTRUCTION_COVERED -Sum).Sum; Write-Host ('Covered instructions: ' + $n)"
if /I "%SUITE%"=="evosuite" (
  powershell -NoProfile -Command "$r=Import-Csv -LiteralPath '%OUT%\jacoco.csv'; $n=($r | Measure-Object -Property INSTRUCTION_COVERED -Sum).Sum; if ($n -eq 0) { Write-Error 'EvoSuite coverage is still zero: tests may be loading different class bytes'; exit 1 }"
  if errorlevel 1 (
    echo ERROR: EvoSuite tests passed but JaCoCo recorded zero production coverage.
    echo Workspace retained: %WORK%
    exit /b 1
  )
)
echo.
echo SUCCESS: %SUITE% report saved to:
echo %OUT%\index.html
echo Temporary workspace retained: %WORK%
exit /b 0

:failed
echo Temporary workspace retained for debugging: %WORK%
exit /b 1
