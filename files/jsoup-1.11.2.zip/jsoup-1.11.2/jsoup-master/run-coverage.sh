#!/usr/bin/env bash
set -Eeuo pipefail

# Run from the directory containing this script and pom.xml.
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$ROOT"

SUITE="${1:-}"
case "${SUITE,,}" in
  human|evosuite|codex) SUITE="${SUITE,,}" ;;
  *) echo 'Usage: ./run-coverage.sh human|evosuite|codex' >&2; exit 1 ;;
esac

WORK="$ROOT/.coverage-work"
OUT="$ROOT/coverage-reports/$SUITE"
JACOCO_CLI='org.jacoco.cli-0.8.12-nodeps.jar'
TESTPATTERN=''

fail() { echo "ERROR: $*" >&2; echo "Workspace retained: $WORK" >&2; exit 1; }
[[ -f "$ROOT/pom.xml" ]] || fail "Place this file beside jsoup's pom.xml."
case "$SUITE" in
  evosuite) [[ -d "$ROOT/evosuite-tests" ]] || fail 'evosuite-tests folder not found.'; TESTPATTERN='*_ESTest' ;;
  codex) [[ -d "$ROOT/codex-tests" ]] || fail 'codex-tests folder not found.'; TESTPATTERN='*CodexTest' ;;
esac

# Delete only the known, non-symlink workspace in this project.
[[ "$WORK" == "$ROOT/.coverage-work" && "$WORK" != / && "$WORK" != "$ROOT" ]] || fail 'Unexpected workspace path.'
[[ ! -L "$WORK" ]] || fail 'Workspace is a symlink; refusing to delete it.'
if [[ -e "$WORK" ]]; then
  echo 'Removing previous temporary workspace...'
  rm -rf -- "$WORK" || fail 'Could not remove workspace.'
fi
mkdir -p -- "$WORK"

# Copy the project without copying old reports, build outputs, or git metadata.
echo "Preparing isolated $SUITE workspace..."
if ! (tar -cf - --exclude='./.git' --exclude='./target' --exclude='./.coverage-work' \
    --exclude='./coverage-reports' --exclude='*.log' -C "$ROOT" . | tar -xf - -C "$WORK"); then
  fail 'Failed to create temporary workspace.'
fi

if [[ "$SUITE" != human ]]; then
  rm -rf -- "$WORK/src/test/java"
  mkdir -p -- "$WORK/src/test/java"
  if [[ "$SUITE" == evosuite ]]; then SOURCE="$WORK/evosuite-tests"; else SOURCE="$WORK/codex-tests"; fi
  cp -R -- "$SOURCE/." "$WORK/src/test/java/" || fail 'Failed to copy selected tests.'
  if [[ "$SUITE" == evosuite ]]; then
    find "$WORK/src/test/java" -type f \( -name '*CodexTest.java' -o -name '*CodexTest.class' \) -delete
  else
    find "$WORK/src/test/java" -type f \( -name '*_ESTest.java' -o -name '*_ESTest_scaffolding.java' \) -delete
  fi
fi

if [[ "$SUITE" == evosuite ]]; then
  echo 'Adding EvoSuite runtime to temporary Maven project...'
  # Only the copied POM is modified.
  WORK_DIR="$WORK" python3 - <<'PY' || fail 'Failed to add EvoSuite runtime to temporary pom.xml.'
import os
import xml.etree.ElementTree as ET
path = os.path.join(os.environ['WORK_DIR'], 'pom.xml')
tree = ET.parse(path)
root = tree.getroot()
ns = root.tag.partition('}')[0][1:] if root.tag.startswith('{') else ''
q = lambda name: '{%s}%s' % (ns, name) if ns else name
if ns:
    ET.register_namespace('', ns)
blocks = root.findall(q('dependencies'))
if len(blocks) > 1:
    raise ValueError('Multiple top-level dependencies sections')
deps = blocks[0] if blocks else ET.SubElement(root, q('dependencies'))
for dep in list(deps.findall(q('dependency'))):
    if dep.findtext(q('groupId')) == 'org.evosuite' and dep.findtext(q('artifactId')) == 'evosuite-standalone-runtime':
        deps.remove(dep)
dep = ET.SubElement(deps, q('dependency'))
for key, val in [('groupId','org.evosuite'), ('artifactId','evosuite-standalone-runtime'), ('version','1.0.6'), ('scope','test')]:
    ET.SubElement(dep, q(key)).text = val
tree.write(path, encoding='utf-8', xml_declaration=True)
PY
fi

cd "$WORK"

if [[ "$SUITE" == evosuite ]]; then
  echo 'Compiling EvoSuite tests and production classes...'
  mvn clean test-compile '-DskipTests' || fail 'Maven compilation failed.'

  mkdir -p target/test-classes
  # Absolute path avoids EvoSuite changes to user.dir.
  cat > target/test-classes/jacoco-agent.properties <<PROPS
output=file
destfile=$WORK/target/jacoco.exec
append=false
PROPS

  echo 'Instrumenting production classes offline...'
  mvn org.jacoco:jacoco-maven-plugin:0.8.12:instrument || fail 'JaCoCo offline instrumentation failed.'

  echo 'Running EvoSuite tests against offline-instrumented production classes...'
  mvn surefire:test "-Dtest=$TESTPATTERN" '-DfailIfNoTests=true' '-Dmaven.test.failure.ignore=true' || fail 'Maven execution failed.'

  echo 'Restoring original production classes for reporting...'
  mvn org.jacoco:jacoco-maven-plugin:0.8.12:restore-instrumented-classes || fail 'Failed to restore production classes.'
else
  echo "Running $SUITE tests with JaCoCo Java agent..."
  args=(clean org.jacoco:jacoco-maven-plugin:0.8.12:prepare-agent test '-DfailIfNoTests=true' '-Dmaven.test.failure.ignore=true')
  [[ -z "$TESTPATTERN" ]] || args+=("-Dtest=$TESTPATTERN")
  mvn "${args[@]}" || fail 'Maven compilation or execution failed.'
fi

[[ -f target/jacoco.exec ]] || fail 'JaCoCo execution data not found in target/jacoco.exec.'

echo 'Preparing JaCoCo CLI...'
mvn dependency:copy '-Dartifact=org.jacoco:org.jacoco.cli:0.8.12:jar:nodeps' '-DoutputDirectory=.' || fail 'Could not download JaCoCo CLI.'
[[ -f "$JACOCO_CLI" ]] || fail "JaCoCo CLI JAR not found: $JACOCO_CLI"

[[ ! -L "$OUT" ]] || fail 'Report directory is a symlink; refusing to delete it.'
rm -rf -- "$OUT" || fail 'Could not remove old report.'
mkdir -p -- "$OUT" || fail 'Could not create report directory.'

echo "Generating $SUITE coverage using JaCoCo CLI..."
java -jar "$JACOCO_CLI" report target/jacoco.exec \
  --classfiles target/classes --sourcefiles src/main/java \
  --html "$OUT" --csv "$OUT/jacoco.csv" || fail 'JaCoCo CLI report generation failed.'
[[ -f "$OUT/index.html" && -f "$OUT/jacoco.csv" ]] || fail 'Coverage report files not generated.'

python3 - "$OUT/jacoco.csv" "$SUITE" <<'PY' || fail 'Failed to verify coverage CSV.'
import csv, sys
with open(sys.argv[1], newline='') as f:
    covered = sum(int(row['INSTRUCTION_COVERED']) for row in csv.DictReader(f))
print('Covered instructions:', covered)
if sys.argv[2] == 'evosuite' and covered == 0:
    sys.exit('EvoSuite coverage is still zero: tests may be loading different class bytes')
PY

echo
echo "SUCCESS: $SUITE report saved to:"
echo "$OUT/index.html"
echo "Temporary workspace retained: $WORK"
